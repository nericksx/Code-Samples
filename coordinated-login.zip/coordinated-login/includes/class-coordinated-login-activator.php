<?php

/**
 * Fired during plugin activation
 *
 * @link       https://nicoleinpdx.com
 * @since      1.0.0
 *
 * @package    Coordinated_Login
 * @subpackage Coordinated_Login/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Coordinated_Login
 * @subpackage Coordinated_Login/includes
 * @author     Nicole Erickson <nerickson@portmorgan.com>
 */
class Coordinated_Login_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
