<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://nicoleinpdx.com
 * @since      1.0.0
 *
 * @package    Coordinated_Login
 * @subpackage Coordinated_Login/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Coordinated_Login
 * @subpackage Coordinated_Login/includes
 * @author     Nicole Erickson <nerickson@portmorgan.com>
 */
class Coordinated_Login_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
