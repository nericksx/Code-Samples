<?php

/**
 * The plugin bootstrap file
 * Boilerplate by https://wppb.me
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://nicoleinpdx.com
 * @since             1.0.0
 * @package           Coordinated_Login
 *
 * @wordpress-plugin
 * Plugin Name:       Coordinated Login
 * Plugin URI:        https://nicoleinpdx.com/wp/plugins
 * Description:       Look like a pro, and match the WP Admin login style to your site design.
 * Version:           1.0.0
 * Author:            Nicole Erickson
 * Author URI:        https://nicoleinpdx.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       coordinated-login
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'coordinated-login_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-coordinated-login-activator.php
 */
function activate_coordinated_login() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-coordinated-login-activator.php';
	Coordinated_Login_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-coordinated-login-deactivator.php
 */
function deactivate_coordinated_login() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-coordinated-login-deactivator.php';
	Coordinated_Login_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_coordinated_login' );
register_deactivation_hook( __FILE__, 'deactivate_coordinated_login' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-coordinated-login.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */


add_action('admin_menu', 'coordinated_login_setup_menu');
 
function coordinated_login_setup_menu(){
        add_menu_page( 'Coordinated Login', 'Coordinated Login', 'manage_options', 'coordinated-login', 'upload_login_stylesheet' );
}


function upload_login_stylesheet() {
	upload_style();
	?>
			<h2>Upload a File</h2>
			<form method="post" enctype="multipart/form-data">
					<input type='file' id='stylesheet' name='stylesheet'></input>
					<?php submit_button('Upload') ?>
			</form>
			
			<p class="mybutton">Click</p>

	<?php
	}	

	function upload_style(){
			// First check if the file appears on the _FILES array
			if(isset($_FILES['stylesheet'])){
					$upload_dir = wp_upload_dir();
					$file_name = $_FILES['stylesheet']['name'];
					$uploaded_file =  $upload_dir['url'] . '/' . $file_name;
					// Use the wordpress function to upload
					// stylesheet corresponds to the position in the $_FILES array
					$uploaded=media_handle_upload('stylesheet', 0);
					// Error checking using WP functions
					if(is_wp_error($uploaded)){
							echo "Error uploading file: " . $uploaded->get_error_message();
					} else{
							echo "File upload successful!";
							echo '<br>';
							echo $file_name;
					}
					
			}
			
	}

	

	function use_my_script(){
			wp_register_script( 'custom-script', plugins_url( 'admin/js/coordinated-login-admin.js', __FILE__ ), array( 'jquery' ), null, true );
			wp_enqueue_script( 'custom-script' );
	}
	add_action( 'admin_enqueue_scripts', 'use_my_script' );
	
	function style_the_login() {
		wp_enqueue_style('login-styles', get_theme_file_uri( 'login-style_v1.css' ) );
	} 

	add_action('login_enqueue_scripts', 'style_the_login');	
	
?>